# socks examples

## TypeScript Examples

[Connect command](typescript/connectExample.md)

[Bind command](typescript/bindExample.md)

[Associate command](typescript/associateExample.md)

## JavaScript Examples

[Connect command](javascript/connectExample.md)

[Bind command](javascript/bindExample.md)

[Associate command](javascript/associateExample.md)